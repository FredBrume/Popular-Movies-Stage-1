package com.example.fredbrume.popularmovies.util;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MovieDBjsonUtils {

    public static ArrayList<Map<String,String>> getMovieDetailsArrayListFromJson(String posterUrlString) throws JSONException {

        Map<String,String> parsedPosterData;

        final String title="title";

        final String poster_path="poster_path";

        final String release_date="release_date";

        final String vote_average="vote_avarage";

        final String overview="overview";

        ArrayList<Map<String,String>> posterStringObj;

        JSONObject posterJsonObject = new JSONObject(posterUrlString);

        JSONArray movieDetailsArray = posterJsonObject.getJSONArray("results");

        if (movieDetailsArray != null) {

            posterStringObj = new ArrayList<>(movieDetailsArray.length());

            for (int i = 0; i < movieDetailsArray.length(); ++i) {

                JSONObject posterObject = movieDetailsArray.getJSONObject(i);

                parsedPosterData=new HashMap<>();

                parsedPosterData.put(title,String.valueOf(posterObject.get("title")));
                parsedPosterData.put(poster_path,String.valueOf(posterObject.get("poster_path")));
                parsedPosterData.put(release_date,String.valueOf(posterObject.get("release_date")));
                parsedPosterData.put(vote_average,String.valueOf(posterObject.get("vote_average")));
                parsedPosterData.put(overview,String.valueOf(posterObject.get("overview")));


                posterStringObj.add(parsedPosterData);

            }

            return posterStringObj;
        }

        return null;
    }
}
