package com.example.fredbrume.popularmovies.view;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.fredbrume.popularmovies.R;
import com.squareup.picasso.Picasso;

import java.util.Map;

public class MovieDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail_);

        ImageView poster= (ImageView) findViewById(R.id.posterView);
        TextView title = (TextView) findViewById(R.id.titleView);
        TextView overview = (TextView) findViewById(R.id.overview);
        TextView year = (TextView) findViewById(R.id.yearView);
        TextView rating = (TextView) findViewById(R.id.vote_averageView);

        Intent intent = getIntent();

        if (intent != null) {

            final String poster_base_path = "http://image.tmdb.org/t/p/original/";

            final String titleData = "title";

            final String poster_path = "poster_path";

            final String release_date = "release_date";

            final String vote_average = "vote_avarage";

            final String overviewData = "overview";


            if (intent.hasExtra(Intent.EXTRA_TEXT)) {
                Map posterMapDetails = (Map) intent.getSerializableExtra(Intent.EXTRA_TEXT);

                title.setText(String.valueOf(posterMapDetails.get(titleData)));
                overview.setText(String.valueOf(posterMapDetails.get(overviewData)));
                year.setText(String.valueOf(posterMapDetails.get(release_date)));
                rating.setText(String.valueOf(posterMapDetails.get(vote_average)));

                Picasso.with(this).load(poster_base_path + posterMapDetails.get(poster_path)).into(poster);

            }
        }
    }
}
