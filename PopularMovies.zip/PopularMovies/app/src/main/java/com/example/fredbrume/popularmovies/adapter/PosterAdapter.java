package com.example.fredbrume.popularmovies.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.example.fredbrume.popularmovies.R;
import com.example.fredbrume.popularmovies.util.NetworkUtils;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.Map;


public class PosterAdapter extends RecyclerView.Adapter<PosterAdapter.PosterViewHolder> {

    private Context context;

    private ArrayList<Map<String, String>> mPosterDataListMap;

    private final PosterAdapterOnClickHandler mClickHandler;


    public PosterAdapter(PosterAdapterOnClickHandler clickHandler) {

        mClickHandler = clickHandler;

    }

    @Override
    public PosterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        context = parent.getContext();
        int layoutIdForListItem = R.layout.poster_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;

        View view = inflater.inflate(layoutIdForListItem, parent, shouldAttachToParentImmediately);

        return new PosterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PosterViewHolder holder, int position) {

        Map<String,String> posterMap = mPosterDataListMap.get(position);

        Picasso.with(context).load(NetworkUtils.buildPosterURL() + posterMap.get("poster_path")).into(holder.listItemPosteriew);
    }

    @Override
    public int getItemCount() {

        if (null == mPosterDataListMap) return 0;
        return mPosterDataListMap.size();
    }

    public void setPosterData(ArrayList<Map<String, String>> mPosterDataListMap) {


        this.mPosterDataListMap = mPosterDataListMap;
        notifyDataSetChanged();
    }

    public interface PosterAdapterOnClickHandler {

        void onClick(Map mPosterDetails);

    }

    public class PosterViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final ImageView listItemPosteriew;


        public PosterViewHolder(View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);

            listItemPosteriew = (ImageView) itemView.findViewById(R.id.tv_item_poster);
        }

        @Override
        public void onClick(View v) {

            int adapterPosition = getAdapterPosition();
            Map mPosterDataMap = (Map) mPosterDataListMap.get(adapterPosition);


            mClickHandler.onClick(mPosterDataMap);

        }
    }
}
